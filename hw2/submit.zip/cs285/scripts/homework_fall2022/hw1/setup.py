# setup.py
from setuptools import setup

setup(
    name='cs285',
    version='0.1.0',
    packages=['cs285'],
)